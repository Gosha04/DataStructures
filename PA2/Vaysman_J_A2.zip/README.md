Joshua Vaysman || Dylan Barlava
2449656 || 2428584
vaysman@chapman.edu || dbarlava@chapman.edu
CPSC 350-02
PA2

Mario.cpp Mario.h
Level.cpp Level.h
Enemy.cpp Enemy.h
World.cpp World.h
main.cpp
input.txt MarioLog.txt

To our awareness there are no run time errors when everything is entered completely

No outside sources were used for this programming assignment

to compile - g++ -o Mario *.cpp
to run - ./Mario input.txt MarioLog.txt
