Joshua Vaysman
2449656
vaysman@chapman.edu
CPSC 350-02
PA1

Source Files:
Model.cpp
Translator.cpp
FileProcessor.cpp
main.cpp

Errors and Limitations:
N/A

References:
To figure out HTML: https://html.com/#Creating_Your_First_HTML_Webpage 
To refresh IO: https://www.geeksforgeeks.org/getline-string-c/

Compile: g++ -o main.exe main.cpp Model.cpp Translator.cpp FileProcessor.cpp

Run: ./main.exe input.txt output.html



